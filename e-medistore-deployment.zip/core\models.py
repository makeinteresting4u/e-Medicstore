from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone
from datetime import timedelta

class User(AbstractUser):
    ROLE_CHOICES = (
        ('ADMIN', 'Hub Admin'),
        ('STORE_OWNER', 'Store Owner'),
    )
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='STORE_OWNER')

class Store(models.Model):
    name = models.CharField(max_length=255)
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name='stores')
    location = models.CharField(max_length=255)
    license_number = models.CharField(max_length=100, unique=True)
    is_hub = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.name} ({'Hub' if self.is_hub else 'Node'})"

class Medicine(models.Model):
    name = models.CharField(max_length=255)
    generic_name = models.CharField(max_length=255)
    category = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    manufacturer = models.CharField(max_length=255)
    price_per_unit = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.name

class Inventory(models.Model):
    store = models.ForeignKey(Store, on_delete=models.CASCADE, related_name='inventory')
    medicine = models.ForeignKey(Medicine, on_delete=models.CASCADE)
    batch_number = models.CharField(max_length=100)
    quantity = models.PositiveIntegerField(default=0)
    expiry_date = models.DateField()
    low_stock_threshold = models.PositiveIntegerField(default=10)

    def is_near_expiry(self):
        return self.expiry_date <= timezone.now().date() + timedelta(days=30)

    def is_low_stock(self):
        return self.quantity <= self.low_stock_threshold

    class Meta:
        verbose_name_plural = "Inventories"
        unique_together = ('store', 'medicine', 'batch_number')

class Order(models.Model):
    STATUS_CHOICES = (
        ('PENDING', 'Pending'),
        ('APPROVED', 'Approved'),
        ('REJECTED', 'Rejected'),
        ('CANCELLED', 'Cancelled'),
    )
    requesting_store = models.ForeignKey(Store, on_delete=models.CASCADE, related_name='outgoing_orders')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='PENDING')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    total_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)

    def __str__(self):
        return f"Order #{self.id} - {self.requesting_store.name}"

class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items')
    medicine = models.ForeignKey(Medicine, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)

    @property
    def total_price(self):
        return self.quantity * self.unit_price

class Invoice(models.Model):
    order = models.OneToOneField(Order, on_delete=models.CASCADE)
    invoice_number = models.CharField(max_length=50, unique=True)
    date_generated = models.DateTimeField(auto_now_add=True)
    pdf_file = models.FileField(upload_to='invoices/', null=True, blank=True)

    def __str__(self):
        return self.invoice_number

class Alert(models.Model):
    ALERT_TYPES = (
        ('EXPIRY', 'Near Expiry'),
        ('LOW_STOCK', 'Low Stock'),
        ('ORDER', 'Order Notification'),
    )
    store = models.ForeignKey(Store, on_delete=models.CASCADE, related_name='alerts')
    message = models.TextField()
    alert_type = models.CharField(max_length=20, choices=ALERT_TYPES)
    is_resolved = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.alert_type} alert for {self.store.name}"
