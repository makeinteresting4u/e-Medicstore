from django import forms
from .models import Order, OrderItem, Medicine

class OrderForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = [] # Order fields are mostly internal

class OrderItemForm(forms.ModelForm):
    class Meta:
        model = OrderItem
        fields = ['medicine', 'quantity']
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['medicine'].queryset = Medicine.objects.all()
