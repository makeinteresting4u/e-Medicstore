from core.models import User, Store, Medicine, Inventory
from django.utils import timezone
from datetime import timedelta
import random

def seed():
    # 1. Ensure Admin and a Store Owner
    admin = User.objects.get(username='admin')
    admin.role = 'ADMIN'
    admin.save()

    owner, _ = User.objects.get_or_create(username='owner1', defaults={'first_name': 'John', 'role': 'STORE_OWNER'})
    owner.set_password('pass123')
    owner.save()

    # 2. Create Hub and a Node
    hub, _ = Store.objects.get_or_create(
        name='Central Hub Warehouse',
        defaults={'owner': admin, 'location': 'Main City', 'license_number': 'HUB-001', 'is_hub': True}
    )

    store1, _ = Store.objects.get_or_create(
        name='Downtown Meds',
        defaults={'owner': owner, 'location': 'Downtown', 'license_number': 'NODE-001', 'is_hub': False}
    )

    # 3. Create Medicines
    meds_data = [
        ('Paracetamol 500mg', 'Paracetamol', 'Analgesic', 1.50),
        ('Amoxicillin 250mg', 'Amoxicillin', 'Antibiotic', 5.00),
        ('Cetirizine 10mg', 'Cetirizine', 'Antihistamine', 2.00),
        ('Ibuprofen 400mg', 'Ibuprofen', 'NSAID', 3.50),
        ('Insulin Pen', 'Insulin', 'Antidiabetic', 45.00),
    ]

    for name, gen, cat, price in meds_data:
        m, _ = Medicine.objects.get_or_create(
            name=name,
            defaults={'generic_name': gen, 'category': cat, 'price_per_unit': price, 'manufacturer': 'PharmaCorp'}
        )
        
        # Add initial stock to HUB
        Inventory.objects.get_or_create(
            store=hub,
            medicine=m,
            batch_number=f"B-{random.randint(100,999)}",
            defaults={
                'quantity': 1000,
                'expiry_date': timezone.now().date() + timedelta(days=365)
            }
        )
        
        # Add low stock for NODE to demonstrate alerts
        Inventory.objects.get_or_create(
            store=store1,
            medicine=m,
            batch_number=f"B-{random.randint(100,999)}",
            defaults={
                'quantity': 5,
                'expiry_date': timezone.now().date() + timedelta(days=365),
                'low_stock_threshold': 10
            }
        )

if __name__ == "__main__":
    seed()
    print("Database seeded successfully!")
