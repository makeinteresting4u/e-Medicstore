from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('inventory/', views.InventoryListView.as_view(), name='inventory_list'),
    path('orders/', views.OrderListView.as_view(), name='order_list'),
    path('orders/create/', views.create_order, name='order_create'),
    path('orders/<int:order_id>/approve/', views.approve_order, name='order_approve'),
    path('alerts/', views.AlertListView.as_view(), name='alert_list'),
    path('invoices/', views.InvoiceListView.as_view(), name='invoice_list'),
    
    # Auth
    path('login/', auth_views.LoginView.as_view(template_name='core/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),
]
