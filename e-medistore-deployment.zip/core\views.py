from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import ListView, CreateView, DetailView, UpdateView
from django.db import transaction
from django.db.models import Sum
from .models import Store, Medicine, Inventory, Order, OrderItem, Invoice, Alert
from .forms import OrderForm, OrderItemForm
import uuid

@login_required
def dashboard(request):
    user = request.user
    if user.role == 'ADMIN':
        # Hub Admin View
        total_stores = Store.objects.filter(is_hub=False).count()
        pending_orders = Order.objects.filter(status='PENDING').count()
        low_stock_alerts = Alert.objects.filter(alert_type='LOW_STOCK', is_resolved=False).count()
        expiry_alerts = Alert.objects.filter(alert_type='EXPIRY', is_resolved=False).count()
        
        context = {
            'role': 'Admin',
            'total_stores': total_stores,
            'pending_orders': pending_orders,
            'low_stock_alerts': low_stock_alerts,
            'expiry_alerts': expiry_alerts,
        }
    else:
        # Store Owner View
        store = request.user.stores.first()
        if not store:
            return render(request, 'core/no_store.html')
            
        inventory_items = Inventory.objects.filter(store=store)
        my_orders = Order.objects.filter(requesting_store=store).order_by('-created_at')[:5]
        my_alerts = Alert.objects.filter(store=store, is_resolved=False).count()
        
        context = {
            'role': 'Store Owner',
            'store': store,
            'inventory_count': inventory_items.count(),
            'recent_orders': my_orders,
            'alert_count': my_alerts,
        }
    return render(request, 'core/dashboard.html', context)

class InventoryListView(LoginRequiredMixin, ListView):
    model = Inventory
    template_name = 'core/inventory_list.html'
    context_object_name = 'items'

    def get_queryset(self):
        if self.request.user.role == 'ADMIN':
            return Inventory.objects.filter(store__is_hub=True)
        return Inventory.objects.filter(store__owner=self.request.user)

@login_required
@transaction.atomic
def create_order(request):
    store = request.user.stores.first()
    if request.method == 'POST':
        # Simplified order creation logic
        medicine_id = request.POST.get('medicine')
        quantity = int(request.POST.get('quantity'))
        medicine = get_object_or_404(Medicine, id=medicine_id)
        
        order = Order.objects.create(requesting_store=store, total_amount=medicine.price_per_unit * quantity)
        OrderItem.objects.create(order=order, medicine=medicine, quantity=quantity, unit_price=medicine.price_per_unit)
        
        # Notify Admin
        Alert.objects.create(
            store=Store.objects.get(is_hub=True),
            message=f"New restock request from {store.name}",
            alert_type='ORDER'
        )
        return redirect('dashboard')
    
    medicines = Medicine.objects.all()
    return render(request, 'core/create_order.html', {'medicines': medicines})

@login_required
@transaction.atomic
def approve_order(request, order_id):
    if request.user.role != 'ADMIN':
        return redirect('dashboard')
        
    order = get_object_or_404(Order, id=order_id)
    hub = Store.objects.get(is_hub=True)
    
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'approve':
            # Check availability in Hub
            for item in order.items.all():
                hub_inv = Inventory.objects.filter(store=hub, medicine=item.medicine).first()
                if not hub_inv or hub_inv.quantity < item.quantity:
                    # Not enough stock in Hub
                    return render(request, 'core/order_detail.html', {'order': order, 'error': f"Insufficient stock for {item.medicine.name} in Hub"})
                
                # Deduct from Hub
                hub_inv.quantity -= item.quantity
                hub_inv.save()
                
                # Add to Node (simplification: assumes first batch or creates new)
                node_inv, created = Inventory.objects.get_or_create(
                    store=order.requesting_store,
                    medicine=item.medicine,
                    defaults={'batch_number': hub_inv.batch_number, 'expiry_date': hub_inv.expiry_date}
                )
                node_inv.quantity += item.quantity
                node_inv.save()
            
            order.status = 'APPROVED'
            order.save()
            
            # Generate Invoice
            Invoice.objects.create(
                order=order,
                invoice_number=f"INV-{uuid.uuid4().hex[:8].upper()}"
            )
            
        elif action == 'reject':
            order.status = 'REJECTED'
            order.save()
            
        return redirect('dashboard')
    
    return render(request, 'core/order_detail.html', {'order': order})

class OrderListView(LoginRequiredMixin, ListView):
    model = Order
    template_name = 'core/order_list.html'
    context_object_name = 'orders'

    def get_queryset(self):
        if self.request.user.role == 'ADMIN':
            return Order.objects.all().order_by('-created_at')
        return Order.objects.filter(requesting_store__owner=self.request.user).order_by('-created_at')

class AlertListView(LoginRequiredMixin, ListView):
    model = Alert
    template_name = 'core/alert_list.html'
    context_object_name = 'alerts'

    def get_queryset(self):
        if self.request.user.role == 'ADMIN':
            return Alert.objects.filter(store__is_hub=True)
        return Alert.objects.filter(store__owner=self.request.user)

class InvoiceListView(LoginRequiredMixin, ListView):
    model = Invoice
    template_name = 'core/invoice_list.html'
    context_object_name = 'invoices'

    def get_queryset(self):
        if self.request.user.role == 'ADMIN':
            return Invoice.objects.all()
        return Invoice.objects.filter(order__requesting_store__owner=self.request.user)
